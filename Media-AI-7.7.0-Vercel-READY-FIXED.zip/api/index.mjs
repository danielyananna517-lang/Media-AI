import { handler } from '../server-core.mjs';
export default handler;
