const $ = (id) => document.getElementById(id);

async function api(path, options={}) {
  const res = await fetch(path, { headers:{'content-type':'application/json'}, ...options });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function renderProviders(p) {
  $('providers').innerHTML = Object.entries(p).map(([name, connected]) => `
    <div class="provider"><span><span class="dot ${connected?'on':''}"></span>${name}</span><span class="muted">${connected?'connected':'not connected'}</span></div>
  `).join('');
}

function renderMemory(data) {
  const items = data.items || [];
  $('memoryList').innerHTML = items.length ? items.map(i => `
    <div class="memory-item"><div><b>${escapeHtml(i.title || 'Untitled')}</b><div class="muted">${new Date(i.createdAt).toLocaleString()}</div></div><span class="pill">${escapeHtml(i.status || 'draft')}</span></div>
  `).join('') : '<div class="empty">Content Memory-ը դեռ դատարկ է։</div>';
}

function escapeHtml(v='') { return String(v).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }

async function refresh() {
  const h = await api('/api/health');
  $('status').textContent = h.ok ? 'Independent core: online' : 'Offline';
  renderProviders(h.providers);
  renderMemory(await api('/api/content'));
  refreshYouTube();
}

$('researchBtn').onclick = async () => {
  const q = $('query').value.trim(); if (!q) return;
  $('researchResults').innerHTML = '<div class="empty">Researching…</div>';
  try {
    const urls = $('researchUrls').value.split('\n').map(v=>v.trim()).filter(Boolean);
    const data = await api('/api/research', {method:'POST', body:JSON.stringify({query:q, urls})});
    if (!data.results?.length) {
      $('researchResults').innerHTML = `<div class="empty">${escapeHtml(data.message || 'No results.')}</div>`;
      return;
    }
    $('researchResults').innerHTML = data.results.map(r => `<div class="result"><a href="${r.url}" target="_blank" rel="noreferrer">${escapeHtml(r.title || r.url)}</a><div class="muted">${escapeHtml((r.highlights||[]).join(' '))}</div></div>`).join('');
    $('compareJson').value = JSON.stringify(data, null, 2);
    try { const c = await api('/api/compare-sources',{method:'POST',body:JSON.stringify(data)}); $('researchBrief').textContent = JSON.stringify(await api('/api/analyze-research',{method:'POST',body:JSON.stringify({research:data,comparison:c})}),null,2); } catch {}
  } catch(e) { $('researchResults').innerHTML = `<div class="error">${escapeHtml(e.message)}</div>`; }
};

$('compareBtn').onclick = async () => {
  const raw = $('compareJson').value.trim();
  if (!raw) return;
  $('compareOut').textContent = 'Comparing…';
  try {
    const parsed = JSON.parse(raw);
    $('compareOut').textContent = JSON.stringify(await api('/api/compare-sources',{method:'POST',body:JSON.stringify(parsed)}),null,2);
  } catch(e){ $('compareOut').textContent = `Error: ${e.message}`; }
};

$('prodBtn').onclick = async () => {
  const topic = $('prodTopic').value.trim();
  const raw = $('prodScript').value.trim();
  if (!topic && !raw) return;
  $('prodOut').textContent = 'Building…';
  try {
    let script = raw;
    try { script = JSON.parse(raw); } catch {}
    const result = await api('/api/production',{method:'POST',body:JSON.stringify({topic,script})});
    $('prodOut').textContent = JSON.stringify({title:result.title,duration:result.totalDurationSeconds,assetChecklist:result.assetChecklist,subtitlesSrt:result.subtitlesSrt},null,2);
  } catch(e){ $('prodOut').textContent = `Error: ${e.message}`; }
};

async function refreshYouTube(){
  try {
    const y = await api('/api/youtube/status');
    $('youtubeStatus').innerHTML = `<span><span class="dot ${y.configured?'on':''}"></span>YouTube ${y.configured?'credentials ready':'not connected'}</span><span class="muted">manual approval: ${y.manualApproval ? 'yes':'no'}</span>`;
  } catch(e){ $('youtubeStatus').textContent = e.message; }
}

$('strategyBtn').onclick = async () => {
  const topic = $('topicStrategy').value.trim(); if (!topic) return;
  $('strategyOut').textContent = 'Generating…';
  try { $('strategyOut').textContent = JSON.stringify(await api('/api/generate',{method:'POST',body:JSON.stringify({task:'strategy',input:{topic}})}),null,2); }
  catch(e){ $('strategyOut').textContent = `Error: ${e.message}`; }
};

$('scriptBtn').onclick = async () => {
  const topic = $('topicScript').value.trim(); if (!topic) return;
  $('scriptOut').textContent = 'Generating…';
  try { $('scriptOut').textContent = JSON.stringify(await api('/api/generate',{method:'POST',body:JSON.stringify({task:'script',input:{topic}})}),null,2); }
  catch(e){ $('scriptOut').textContent = `Error: ${e.message}`; }
};

$('saveMemory').onclick = async () => {
  const title = $('memoryTitle').value.trim(); if (!title) return;
  await api('/api/content',{method:'POST',body:JSON.stringify({title,status:$('memoryStatus').value})});
  $('memoryTitle').value='';
  renderMemory(await api('/api/content'));
  refreshYouTube();
};

refresh().catch(e => { $('status').textContent='Error'; console.error(e); });


$('qaBtn').onclick = async () => {
  const text = $('qaText').value.trim(); if (!text) return;
  $('qaOut').textContent = 'Checking…';
  try { $('qaOut').textContent = JSON.stringify(await api('/api/qa',{method:'POST',body:JSON.stringify({text})}),null,2); }
  catch(e){ $('qaOut').textContent = `Error: ${e.message}`; }
};

$('adaptBtn').onclick = async () => {
  const text = $('adaptText').value.trim(), topic = $('adaptTopic').value.trim(); if (!text && !topic) return;
  $('adaptOut').textContent = 'Creating…';
  try { $('adaptOut').textContent = JSON.stringify(await api('/api/adapt',{method:'POST',body:JSON.stringify({topic,text})}),null,2); }
  catch(e){ $('adaptOut').textContent = `Error: ${e.message}`; }
};

$('learnBtn').onclick = async () => {
  $('learnOut').textContent = 'Analyzing…';
  const metrics = {views:+$('mViews').value||0, likes:+$('mLikes').value||0, comments:+$('mComments').value||0, ctr:+$('mCtr').value||0, avgViewPercent:+$('mAvp').value||0};
  try { $('learnOut').textContent = JSON.stringify(await api('/api/analytics/learning',{method:'POST',body:JSON.stringify({metrics})}),null,2); }
  catch(e){ $('learnOut').textContent = `Error: ${e.message}`; }
};

$('pipelineBtn').onclick = async () => {
  const topic = $('pipelineTopic').value.trim(); if (!topic) return;
  $('pipelineOut').textContent = 'Running pipeline…';
  try {
    const urls = $('pipelineUrls').value.split('\n').map(v=>v.trim()).filter(Boolean);
    const result = await api('/api/pipeline',{method:'POST',body:JSON.stringify({topic, urls})});
    $('pipelineOut').textContent = JSON.stringify({status:result.status, researchProvider:result.research?.provider, uniqueSources:result.sourceComparison?.uniqueDomains, strategyProvider:result.strategy?.provider, scriptProvider:result.script?.provider, qa:result.qa, adaptations:result.adaptations?.map(a=>a.platform), productionSeconds:result.production?.totalDurationSeconds, subtitleLines:result.production?.subtitles?.length},null,2);
    renderMemory(await api('/api/content'));
  } catch(e){ $('pipelineOut').textContent = `Error: ${e.message}`; }
};
