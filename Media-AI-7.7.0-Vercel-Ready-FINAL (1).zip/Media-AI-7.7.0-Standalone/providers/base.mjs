export class ProviderError extends Error {
  constructor(message, provider, details = {}) {
    super(message);
    this.name = 'ProviderError';
    this.provider = provider;
    this.details = details;
  }
}

export function providerStatus(name, envKey) {
  return {
    name,
    connected: Boolean(process.env[envKey]),
    envKey
  };
}
