import { ProviderError } from './base.mjs';

export async function geminiGenerate({ task, input = {} }) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new ProviderError('Gemini is not connected.', 'gemini');
  const model = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
  const prompt = task === 'strategy'
    ? `Create a concise evidence-aware content strategy for: ${input.topic || ''}. Research brief: ${JSON.stringify(input.researchBrief || {})}. Separate supported observations from hypotheses. Include audience, 3 pillars, formats, cadence and metrics.`
    : `Create a YouTube script outline for: ${input.topic || ''}. Include hook, sections, sources-to-check and CTA.`;
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] })
  });
  const data = await res.json();
  if (!res.ok) throw new ProviderError(data?.error?.message || 'Gemini request failed.', 'gemini', data);
  const text = data?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('') || JSON.stringify(data);
  return { provider: 'gemini', text };
}
