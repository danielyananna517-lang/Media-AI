import { ProviderError } from './base.mjs';
import { URL } from 'node:url';

function assertSafeUrl(raw) {
  const u = new URL(raw);
  if (!['http:', 'https:'].includes(u.protocol)) throw new ProviderError('Only http/https URLs are allowed.', 'url');
  const host = u.hostname.toLowerCase();
  if (host === 'localhost' || host.endsWith('.localhost') || host === '127.0.0.1' || host === '::1' || host === '0.0.0.0') {
    throw new ProviderError('Local/private URLs are blocked.', 'url');
  }
  if (/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[0-1])\.)/.test(host)) {
    throw new ProviderError('Private network URLs are blocked.', 'url');
  }
  return u;
}

function cleanHtml(html) {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

function pickTitle(html, fallback) {
  const m = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  return m ? cleanHtml(m[1]).slice(0, 300) : fallback;
}

export async function urlImport({ urls = [] } = {}) {
  const unique = [...new Set(urls.map(x => String(x).trim()).filter(Boolean))].slice(0, 8);
  const results = [];
  const errors = [];
  for (const raw of unique) {
    try {
      const u = assertSafeUrl(raw);
      const res = await fetch(u, { headers: { 'user-agent': 'MediaAI-Independent/0.3 ResearchImporter' }, redirect: 'follow' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const html = (await res.text()).slice(0, 600000);
      const text = cleanHtml(html).slice(0, 5000);
      results.push({ title: pickTitle(html, u.hostname), url: u.toString(), domain: u.hostname.replace(/^www\./,''), highlights: text ? [text.slice(0, 1200)] : [], imported: true });
    } catch (e) {
      errors.push({ url: raw, message: e.message });
    }
  }
  return { provider: 'url', results, errors };
}
