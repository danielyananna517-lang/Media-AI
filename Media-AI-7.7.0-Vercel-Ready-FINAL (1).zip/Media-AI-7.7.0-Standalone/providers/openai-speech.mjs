import { ProviderError } from './base.mjs';
import { createGenerationId } from './contracts.mjs';

export const openaiSpeechProvider = {
  name: 'openai-speech',
  async generate(request) {
    const key = process.env.OPENAI_API_KEY;
    if (!key) throw new ProviderError('OpenAI Speech API is not configured. Set OPENAI_API_KEY.', 'openai-speech', { code:'MISSING_CREDENTIAL' });
    const model = request.model || process.env.OPENAI_TTS_MODEL || 'gpt-4o-mini-tts';
    const responseFormat = request.responseFormat || 'mp3';
    const payload = { model, input: request.input, voice: request.voice || 'alloy', response_format: responseFormat };
    if (request.instructions && model !== 'tts-1' && model !== 'tts-1-hd') payload.instructions = request.instructions;
    const response = await fetch('https://api.openai.com/v1/audio/speech', { method:'POST', headers:{authorization:`Bearer ${key}`,'content-type':'application/json'}, body:JSON.stringify(payload), signal:AbortSignal.timeout(120000) });
    if (!response.ok) { const data=await response.json().catch(()=>({})); throw new ProviderError(data?.error?.message || `OpenAI Speech API failed with ${response.status}.`,'openai-speech',{httpStatus:response.status,response:data,retryable:response.status===429||response.status>=500}); }
    const bytes=Buffer.from(await response.arrayBuffer());
    const mime = {mp3:'audio/mpeg',opus:'audio/ogg',aac:'audio/aac',flac:'audio/flac',wav:'audio/wav',pcm:'audio/pcm'}[responseFormat] || 'audio/mpeg';
    return { provider:'openai', model, format:responseFormat, mimeType:mime, generationId:createGenerationId('openai-tts'), bytes };
  }
};
