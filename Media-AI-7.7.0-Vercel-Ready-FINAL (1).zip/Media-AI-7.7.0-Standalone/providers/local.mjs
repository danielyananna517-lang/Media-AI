export function localGenerate({ task, input = {} }) {
  const topic = input.topic || 'your topic';
  if (task === 'strategy') {
    return {
      title: `Content strategy: ${topic}`,
      audience: 'General audience, adapted per platform and language',
      pillars: [
        'Useful explanation',
        'Curiosity / discovery',
        'Practical takeaway'
      ],
      formats: ['Short-form video', 'Long-form explainer', 'Carousel / post'],
      cadence: 'Start with a sustainable test cadence and adjust from analytics.'
    };
  }
  if (task === 'script') {
    return {
      title: topic,
      hook: `Here is the useful thing about ${topic} that most people miss.`,
      body: [
        `Context: explain the problem or question in one sentence.`,
        `Value: give 2–3 concrete points supported by sources when research is available.`,
        `Takeaway: end with one memorable action or conclusion.`
      ],
      cta: 'Invite the viewer to watch the next related video.'
    };
  }
  return {
    message: `Local mode prepared a structured draft for ${topic}. Connect a provider for richer generation.`
  };
}
