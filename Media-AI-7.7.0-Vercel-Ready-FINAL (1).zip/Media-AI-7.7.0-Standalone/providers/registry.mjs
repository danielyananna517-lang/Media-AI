import { localGenerate } from './local.mjs';
import { openaiGenerate } from './openai.mjs';
import { geminiGenerate } from './gemini.mjs';
import { exaSearch } from './exa.mjs';
import { urlImport } from './url.mjs';

export function getProviderStatus() {
  return {
    openai: Boolean(process.env.OPENAI_API_KEY),
    gemini: Boolean(process.env.GEMINI_API_KEY),
    exa: Boolean(process.env.EXA_API_KEY),
    youtube: Boolean(process.env.YOUTUBE_CLIENT_ID && process.env.YOUTUBE_CLIENT_SECRET && process.env.YOUTUBE_REFRESH_TOKEN),
    urlImport: true,
    local: true
  };
}

export async function generateWithFallback(task, input = {}, priority = ['openai', 'gemini', 'local']) {
  const errors = [];
  const factories = {
    openai: () => openaiGenerate({ task, input }),
    gemini: () => geminiGenerate({ task, input }),
    local: () => Promise.resolve({ provider: 'local', ...localGenerate({ task, input }) })
  };
  for (const name of priority) {
    if (!factories[name]) continue;
    try { return await factories[name](); }
    catch (e) { errors.push({ provider: name, message: e.message }); }
  }
  return { provider: 'local', ...localGenerate({ task, input }), errors };
}

export async function researchWithFallback(query, numResults = 8, priority = ['exa', 'url', 'local'], urls = []) {
  const errors = [];
  for (const name of priority) {
    try {
      if (name === 'exa') return await exaSearch({ query, numResults });
      if (name === 'url' && urls.length) return await urlImport({ urls });
      if (name === 'local') return { provider: 'local', results: [], message: 'No live search provider connected; add source URLs or connect a search adapter.', errors };
    } catch (e) { errors.push({ provider: name, message: e.message }); }
  }
  return { provider: 'local', results: [], message: 'No research provider available.', errors };
}
