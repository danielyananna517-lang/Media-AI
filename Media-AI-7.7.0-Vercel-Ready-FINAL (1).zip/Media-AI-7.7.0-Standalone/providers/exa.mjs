import { ProviderError } from './base.mjs';

export async function exaSearch({ query, numResults = 8 }) {
  const key = process.env.EXA_API_KEY;
  if (!key) throw new ProviderError('Exa is not connected.', 'exa');
  const res = await fetch('https://api.exa.ai/search', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': key },
    body: JSON.stringify({ query, numResults, contents: { highlights: true } })
  });
  const data = await res.json();
  if (!res.ok) throw new ProviderError(data?.error || 'Exa request failed.', 'exa', data);
  return {
    provider: 'exa',
    results: (data.results || []).map(r => ({ title: r.title, url: r.url, highlights: r.highlights || [] }))
  };
}
