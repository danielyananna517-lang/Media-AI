import { GenerationRequest } from './contracts.mjs';

export class ProviderManager {
  constructor() { this.providers = new Map(); }
  register(provider) {
    if (!provider?.name || typeof provider.generate !== 'function') throw new Error('Invalid provider adapter.');
    this.providers.set(provider.name, provider);
  }
  get(name) { return this.providers.get(name); }
  list() { return [...this.providers.values()].map(p => p.name); }
  async generate(requestLike, providerName) {
    const request = requestLike instanceof GenerationRequest ? requestLike : new GenerationRequest(requestLike);
    const provider = this.get(providerName);
    if (!provider) throw new Error(`Provider not registered: ${providerName}`);
    return provider.generate(request);
  }
}
