import { ProviderError } from './base.mjs';
import { createGenerationId } from './contracts.mjs';

async function call(path, init={}) {
  const key=process.env.OPENAI_API_KEY;
  if(!key) throw new ProviderError('OpenAI Video API is not configured. Set OPENAI_API_KEY.','openai-video',{code:'MISSING_CREDENTIAL'});
  const response=await fetch(`https://api.openai.com/v1${path}`,{...init,headers:{authorization:`Bearer ${key}`,...(init.headers||{})},signal:init.signal||AbortSignal.timeout(120000)});
  return response;
}
export const openaiVideoProvider = {
  name:'openai-video',
  async generate(request){
    const model=request.model||process.env.OPENAI_VIDEO_MODEL||'sora-2';
    const form=new FormData(); form.set('model',model); form.set('prompt',request.prompt); form.set('seconds',String(request.seconds||'4')); form.set('size',request.size||'720x1280');
    const response=await call('/videos',{method:'POST',body:form}); const data=await response.json().catch(()=>({}));
    if(!response.ok) throw new ProviderError(data?.error?.message||`OpenAI Video API failed with ${response.status}.`,'openai-video',{httpStatus:response.status,response:data,retryable:response.status===429||response.status>=500});
    return { provider:'openai', model:data.model||model, generationId:createGenerationId('openai-video'), videoId:data.id, status:data.status||'queued', progress:data.progress||0, seconds:data.seconds, size:data.size };
  },
  async retrieve(videoId){
    const response=await call(`/videos/${encodeURIComponent(videoId)}`,{method:'GET'}); const data=await response.json().catch(()=>({}));
    if(!response.ok) throw new ProviderError(data?.error?.message||`OpenAI Video retrieve failed with ${response.status}.`,'openai-video',{httpStatus:response.status,response:data,retryable:response.status===429||response.status>=500});
    return {videoId:data.id,status:data.status,progress:data.progress||0,model:data.model,seconds:data.seconds,size:data.size,error:data.error||null,completedAt:data.completed_at||null,expiresAt:data.expires_at||null};
  },
  async download(videoId){
    const response=await call(`/videos/${encodeURIComponent(videoId)}/content`,{method:'GET'});
    if(!response.ok) { const data=await response.json().catch(()=>({})); throw new ProviderError(data?.error?.message||`OpenAI Video content failed with ${response.status}.`,'openai-video',{httpStatus:response.status,response:data,retryable:response.status===429||response.status>=500}); }
    return response;
  }
};
