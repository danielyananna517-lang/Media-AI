import { ProviderError } from './base.mjs';

export async function openaiGenerate({ task, input = {} }) {
  const key = process.env.OPENAI_API_KEY;
  if (!key) throw new ProviderError('OpenAI is not connected.', 'openai');
  const model = process.env.OPENAI_MODEL || 'gpt-5.6-luna';
  const prompt = buildPrompt(task, input);
  const res = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: `Bearer ${key}` },
    body: JSON.stringify({ model, input: prompt })
  });
  const data = await res.json();
  if (!res.ok) throw new ProviderError(data?.error?.message || 'OpenAI request failed.', 'openai', data);
  return { provider: 'openai', text: data.output_text || JSON.stringify(data) };
}

function buildPrompt(task, input) {
  const topic = input.topic || '';
  if (task === 'strategy') return `Create a concise evidence-aware content strategy for topic: ${topic}. Research brief: ${JSON.stringify(input.researchBrief || {})}. Separate supported observations from hypotheses. Include audience, 3 content pillars, formats, cadence, and measurable hypotheses.`;
  if (task === 'script') return `Write a YouTube script outline for topic: ${topic}. Include hook, body sections, source placeholders, CTA, and a fact-check checklist.`;
  return `Help with Media AI task ${task}. Input: ${JSON.stringify(input)}`;
}
