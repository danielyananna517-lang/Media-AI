// YouTube adapter seam. Publishing stays intentionally user-controlled.
export function youtubeConfigured() {
  return Boolean(process.env.YOUTUBE_CLIENT_ID && process.env.YOUTUBE_CLIENT_SECRET && process.env.YOUTUBE_REFRESH_TOKEN);
}

export function youtubeAdapterInfo() {
  return {
    configured: youtubeConfigured(),
    mode: 'oauth2-refresh-token',
    autoPublish: false,
    note: 'Publishing is not triggered automatically by the core.'
  };
}
