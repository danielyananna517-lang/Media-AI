import { ProviderError } from './base.mjs';
import { createGenerationId } from './contracts.mjs';

export const openaiImageProvider = {
  name: 'openai-image',
  async generate(request) {
    const key = process.env.OPENAI_API_KEY;
    if (!key) throw new ProviderError('OpenAI Image API is not configured. Set OPENAI_API_KEY in .env.', 'openai-image', { code: 'MISSING_CREDENTIAL' });
    const model = request.model || process.env.OPENAI_IMAGE_MODEL || 'gpt-image-2';
    const generationId = createGenerationId('openai');
    const body = {
      model,
      prompt: request.prompt,
      n: 1,
      ...(request.size ? { size: request.size } : {}),
      ...(request.format ? { output_format: request.format } : { output_format: 'png' }),
      quality: request.metadata?.quality || 'auto'
    };
    const response = await fetch('https://api.openai.com/v1/images/generations', {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${key}` },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(120000)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new ProviderError(data?.error?.message || `OpenAI Image API failed with ${response.status}.`, 'openai-image', { httpStatus: response.status, response: data, retryable: response.status === 429 || response.status >= 500 });
    const b64 = data?.data?.[0]?.b64_json;
    if (!b64) throw new ProviderError('OpenAI returned no image data.', 'openai-image', { response: data });
    return { provider: 'openai', model, generationId, mimeType: body.output_format === 'jpeg' ? 'image/jpeg' : body.output_format === 'webp' ? 'image/webp' : 'image/png', bytes: Buffer.from(b64, 'base64'), apiCreatedAt: data.created ? new Date(data.created * 1000).toISOString() : new Date().toISOString(), responseMetadata: { created: data.created ?? null, output_format: body.output_format, quality: body.quality, size: request.size ?? null } };
  }
};
