export const ASSET_TYPES = Object.freeze(['IMAGE', 'VIDEO', 'AUDIO', 'COVER', 'PDF']);
export const ASSET_STATUSES = Object.freeze(['GENERATING', 'PROCESSING', 'VALIDATING', 'READY', 'FAILED', 'REJECTED']);

export class GenerationRequest {
  constructor({ type, prompt, model, size = null, format = null, inputAssets = [], metadata = {} }) {
    if (!ASSET_TYPES.includes(type)) throw new Error(`Unsupported asset type: ${type}`);
    if (!String(prompt || '').trim()) throw new Error('Prompt is required.');
    this.type = type;
    this.prompt = String(prompt).trim();
    this.model = String(model || '').trim();
    this.size = size;
    this.format = format;
    this.inputAssets = Array.isArray(inputAssets) ? inputAssets : [];
    this.metadata = metadata && typeof metadata === 'object' ? metadata : {};
  }
}

export function createGenerationId(prefix = 'gen') {
  return `${prefix}_${crypto.randomUUID()}`;
}
