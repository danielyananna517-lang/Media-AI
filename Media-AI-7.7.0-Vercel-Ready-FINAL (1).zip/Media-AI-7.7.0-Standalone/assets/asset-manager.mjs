import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

export function makeAssetManager({ rootDir, indexFile }) {
  async function readIndex() { try { return JSON.parse(await fs.readFile(indexFile, 'utf8')); } catch { return { assets: [] }; } }
  async function writeIndex(data) { const tmp = `${indexFile}.tmp`; await fs.writeFile(tmp, JSON.stringify(data, null, 2)); await fs.rename(tmp, indexFile); }
  async function save({ buffer, type, provider, model, prompt, size, format, generationId, sourceModule = 'CREATIVE_STUDIO', sourceEntityId = null, metadata = {} }) {
    if (!Buffer.isBuffer(buffer) || !buffer.length) throw new Error('Generated asset bytes are empty.');
    const hash = crypto.createHash('sha256').update(buffer).digest('hex');
    const ext = format === 'jpeg' ? 'jpg' : (format || 'png');
    const assetId = `asset_${crypto.randomUUID()}`;
    const relativePath = path.join('assets', `${assetId}.${ext}`);
    const absolutePath = path.join(rootDir, relativePath);
    await fs.mkdir(path.dirname(absolutePath), { recursive: true });
    await fs.writeFile(absolutePath, buffer);
    const stat = await fs.stat(absolutePath);
    const record = { assetId, type, provider, model, prompt, size: size || null, format: ext, generationId, createdAt: new Date().toISOString(), status: 'READY', uri: `/${relativePath.replaceAll('\\','/')}`, sizeBytes: stat.size, checksum: hash, sourceModule, sourceEntityId, metadata };
    const index = await readIndex(); index.assets.unshift(record); await writeIndex(index); return record;
  }
  return { readIndex, save };
}
