import fs from 'node:fs/promises';
import path from 'node:path';

const PNG = Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a]);
const JPEG = Buffer.from([0xff,0xd8,0xff]);
const WEBP = Buffer.from('RIFF');

export function validateImageBuffer(buf, mimeType) {
  if (!Buffer.isBuffer(buf) || !buf.length) throw new Error('EMPTY_ASSET');
  const ok = mimeType === 'image/png'
    ? buf.subarray(0,8).equals(PNG)
    : mimeType === 'image/jpeg'
      ? buf.subarray(0,3).equals(JPEG)
      : mimeType === 'image/webp'
        ? buf.subarray(0,4).equals(WEBP) && buf.length >= 12 && buf.subarray(8,12).toString('ascii') === 'WEBP'
        : false;
  if (!ok) throw new Error('INVALID_IMAGE_SIGNATURE');
  return { valid:true, sizeBytes:buf.length };
}

export async function validateImageFile(filePath, mimeType) {
  const buf = await fs.readFile(filePath);
  const result = validateImageBuffer(buf, mimeType);
  return { ...result, path:path.basename(filePath) };
}
